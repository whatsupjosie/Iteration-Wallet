# Iteration Wallet — Change Log

## v3.1 (3-Solutions Test Session)

### Round 1 — restore_from_archive: canonical slot conflict (P7)
**Problem:** Restoring an archived file when an active canonical existed
created two protected files for the same project — silent integrity bug.
**Solution (B):** Auto-archive the active canonical first (same as PROMOTE
does), then restore. No data lost. Full log trail of both operations.

### Round 2 — Lightweight heartbeat watcher (P8)
**Problem:** JS watcher called get_all_state() (5 DB reads) every 5 seconds
regardless of whether anything changed.
**Solution (A):** New get_heartbeat() endpoint returns only vault_open,
file_count, event_count, last_event_ts. JS only calls full refresh when
last_event_ts changes. ~80% reduction in DB reads during idle.

### Round 3 — Modal mutex + enforcer reset-on-open (P4)
**Problem:** Single CommandEnforcer instance; no guard against concurrent
modal sessions; stale enforcer state if modal closed without submitting.
**Solution (B):** JS _modalLocked mutex prevents concurrent modals.
reset_enforcer() now called at modal OPEN (not just close) to clear
any stale keystroke state from previous sessions.

### Round 4 — Specific filesystem error surfacing (P6)
**Problem:** destination mkdir failures returned generic "Failed" message.
PermissionError and OSError were swallowed silently.
**Solution (B):** _safe_mkdir() helper catches PermissionError, 
FileNotFoundError, and OSError separately and returns human-readable
messages to the user (and to the log).

## v3.0 (Debug & Zip Session)
- Added COPY, RELEASE, MANUAL ARCHIVE, REMOVE FROM ARCHIVE operations
- Wired all operations through keystroke enforcer
- Added REMOVE_ARCHIVE to CMD_DEF with typedWord:"REMOVE"
- Fixed triggerCmd missing async keyword
- Fixed response key consistency (res.msg / res.error)
- Added modal mutex
