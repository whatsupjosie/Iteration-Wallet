#!/usr/bin/env python3
"""
Iteration Wallet — Launcher
Run this to start the application: python launch.py
Requires: pip install pywebview
"""
from app import start
if __name__ == "__main__":
    start()
