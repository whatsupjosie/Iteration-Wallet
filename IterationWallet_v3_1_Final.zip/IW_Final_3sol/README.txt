ITERATION WALLET — Debugged Release
=====================================
© 2025 Rear View Foresight LLC — Josie Curtsey Cobbley
Feic Mo Chroí — See My Heart.

FILES IN THIS PACKAGE:
  app.py              — Python bridge: VaultAPI + pywebview window launcher
  vault_engine_v3.py  — Core vault engine: SQLite WAL, file watcher, enforcer
  interface.html      — Full UI: wired to engine, no fake data

REQUIREMENTS:
  Python 3.9+
  pywebview  (pip install pywebview)

TO RUN:
  1. Put all three files in the same folder
  2. python app.py
  3. The Iteration Wallet window opens

BUGS FIXED IN THIS BUILD (7 total):
  CRITICAL - CSS: Extra </style> tag closed style block early; btn-pick/spinner
             CSS was falling outside the style block and being ignored.
  CRITICAL - HTML: Orphan <script> tag swallowed the Add File and Promote
             modals — they were inside a script block, not the DOM.
  CRITICAL - app.py: interface.html loaded as relative path; fails on Windows
             and some pywebview backends. Now uses absolute path.
  CRITICAL - app.py: get_all_state() was calling list_vault_files with
             include_archive=False — archived files were never sent to UI.
             Archive District and Contender would always show empty.
  HIGH     - JS: goTo() called from dashboard links but undefined. Now vnGo().
  HIGH     - JS: watcherTs element referenced in JS but never declared in HTML.
  HIGH     - JS: reset_enforcer() called without await in closeModal;
             enforcer may not reset before next command. closeModal is now async.
  ENGINE   - threading.Lock() → threading.RLock() for _db_lock. The watcher
             thread calls _log_event() from inside a _db_lock context, which
             calls _db() which tries to re-acquire _db_lock → deadlock every
             watcher cycle. RLock allows the same thread to re-enter.
